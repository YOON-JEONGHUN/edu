package db연결;

import javax.swing.JOptionPane;

public class 회원수정처리 {

	public static void main(String[] args) throws Exception {
		String id = JOptionPane.showInputDialog("id");
		String tel = JOptionPane.showInputDialog("tel");

		MemberDB db = new MemberDB();
		db.update(id, tel);

	}

}
