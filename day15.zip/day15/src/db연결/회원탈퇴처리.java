package db연결;

import javax.swing.JOptionPane;

public class 회원탈퇴처리 {

	public static void main(String[] args) throws Exception {
		String id = JOptionPane.showInputDialog("id");
		
		MemberDB db = new MemberDB();
		db.delete(id);

	}

}
