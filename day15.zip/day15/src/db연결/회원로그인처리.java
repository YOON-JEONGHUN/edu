package db연결;

import javax.swing.JOptionPane;

public class 회원로그인처리{

	public static void main(String[] args) throws Exception {
		String id = JOptionPane.showInputDialog("id");
		String pw = JOptionPane.showInputDialog("pw");
		String name = JOptionPane.showInputDialog("name");
		String tel = JOptionPane.showInputDialog("tel");

		MemberDB db = new MemberDB();
		db.create(id, pw, name, tel);

	}

}
