package 메서드반환값;

import java.util.Random;

public class 다양한리턴사용2 {

	public static void main(String[] args) {

		다양한리턴22222 r2 = new 다양한리턴22222();

		int result1 = r2.get(100);
		double result2 = r2.get();
		int[] result3 = r2.get2();
		for (int x : result3) {
			System.out.println(x + " ");
		}
		 Random x = r2.get3();
		 System.out.println(x.nextInt());
	}
}