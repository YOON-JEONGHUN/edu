package 메서드반환값;

import java.util.Scanner;

public class 리턴값확인 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(sc);
		String data = sc.next();
		System.out.println(data);
		int data2 = sc.nextInt();
		System.out.println(data2);
	}

}
