package 메서드반환값;

public class 계산기 {
	
	public int add(int x, int y) {
		int result = x + y;
		System.out.println(" " + result);
		return result;
	}
}
