package 메서드반환값;

public class 탁상용화분창업 {

	public static void main(String[] args) {
		int 식물_price = 10000;
		int 화분_price = 5000;
		
		계산기 cal = new 계산기();
		int result1 = cal.add(식물_price, 화분_price);

		int 물뿌리개_price = 3000;
		int 패키지_price = 9000;
		int result2 = cal.add(물뿌리개_price, 패키지_price);
		
		int result3 = cal.add(result1, result2);
		System.out.println("총 계산금액 " + result3);
	}

}
