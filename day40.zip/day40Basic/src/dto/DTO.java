package dto;

public class DTO {

 private String gen;
 private String address;
 private int age;
 private String name;
 private boolean car;
 
 
public String getGen() {
	return gen;
}
public void setGen(String gen) {
	this.gen = gen;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public boolean isCar() {
	return car;
}
public void setCar(boolean car) {
	this.car = car;
}


@Override
public String toString() {
	return "DTO [gen=" + gen + ", address=" + address + ", age=" + age + ", name=" + name + ", car=" + car + "]";
}
 
 
 
 
 
}
