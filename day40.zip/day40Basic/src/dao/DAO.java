package dao;

import dto.DTO;

public class DAO {

	
	public void add(DTO bag) {
		
	}
}
