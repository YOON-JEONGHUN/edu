package datatype;

public class DataType {

	public static void main(String[] args) {
		// 기본데이터 타입 : 정수, 실수, 문자, 논리 => 값
		// 참조데이터 타입 : 나머지는 모두, 배열, 클래스 => 주소
		byte b = 100; // -128 ~ 127, 1byte = 8 bit
		short s = 30000; // 2byte , +-3만
		int i = 100000000; // 4byte, +-21억
		long l = 2200000000L; // 8byte, 21억 이상
		
		double d = 3.32468794152; // 8byte
		float f = 1.2345647f;
		
		char c = 'a'; // 2byte
		System.out.println(c + 1);
		char c1 = 'A';
		System.out.println(c1 + 1);
		
		boolean t = true; // 1byte
		
	}

}
