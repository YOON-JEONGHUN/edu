package datatype;

public class DataType2 {

	public static void main(String[] args) {
		byte b = 100;
		int i = b;
		
		int i2 = 100;
		// byte b2 = i2;   <== 안됨. 작<-- 큰
		byte b2 = (byte)i2;
		
		// RAM에 선언된 타입 변경 불가, 선언할 때 타입이 결정되기 때문에 재선언 불가!
		// 형변환 :  cpu가 타입을 변환, 캐스팅(casting)
		// 캐스팅의 종류 1) 강제, 2) 자동
		
		// 강제캐스팅인 경우, 값의 범위가 해당되는 경우에만 가능
		int i3 = 1000;
		byte b3 = (byte)i3;
		System.out.println(b3); // 값이 -24로 표현됨. byte의 범위를 벗어나서 오류
	}

}
