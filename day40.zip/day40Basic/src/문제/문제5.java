package 문제;

import java.util.ArrayList;
import java.util.Scanner;

import dto.DTO;

public class 문제5 {

	public static void main(String[] args) {

	}
	
	public ArrayList<DTO> friendsList(ArrayList<해시문제> list) {
		ArrayList<DTO> lists = new ArrayList<DTO>();
		
		System.out.println("친구 목록");
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i + 1) + "번  이름: " + lists.get(i).getName());
			System.out.println((i + 1) + "번  나이: " + lists.get(i).getAge());
			System.out.println((i + 1) + "번  성별: " + lists.get(i).getGen());
			System.out.println((i + 1) + "번  주소: " + lists.get(i).getAddress());	
			System.out.println("=============================");		
		}
	return lists;
	} 
	

	public DTO add(ArrayList<해시문제> list) {
		DTO dto = new DTO();
		Scanner sc = new Scanner(System.in);
		System.out.print("추가하실 친구의 정보를 입력해주세요.");
		System.out.println("=================");
		System.out.print("친구 이름 : ");
		String name = sc.next();
		System.out.print("친구 나이 : ");
		int age = sc.nextInt();
		System.out.print("친구 성별 : ");
		String gender = sc.next();
		System.out.print("친구 주소 : ");
		String address = sc.next();
		System.out.print("친구 차소유 여부 : ");
		boolean car = sc.nextBoolean();
		dto.setAddress(address);
		dto.setAge(age);
		dto.setCar(car);
		dto.setGen(gender);
		dto.setName(name);
		return dto;
	}

}