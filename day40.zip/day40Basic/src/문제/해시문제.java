package 문제;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;



public class 해시문제 {
   
   String name;
   int age;
   char gender;
   String address;
   boolean car;
   
   @Override
   public String toString() {
      return "[이름: " + name + ", 나이:" + age + ", 성별:" + gender + ", "
            + "주소: " + address + ", 차량보유: " + car+ "]";
   }

   //메뉴 출력
   public static void menuOut() {
      System.out.println("-------------");
      System.out.println("1. 친구 리스트 출력 ");
      System.out.println("2. 친구 추가 ");
      System.out.println("3. 친구 삭제 ");
      System.out.println("4. 정보 변경 ");
      System.out.println("9. 종료 ");
      System.out.print("메뉴를 선택하시오>> ");
   }
   
   //친구 정보변경
   public static void modify(ArrayList<해시문제> list) {

      Scanner sc = new Scanner(System.in);
      //친구리스트 없을 때 그냥 패스
      if (list.size() == 0){
         System.out.println("친구가 아직 없습니다... 친구를 먼저 사귀세요");
         return;
      }
      //친구리스트 출력
      System.out.println("[친구 리스트]");
      for (int i = 0; i < list.size(); i++) {
         System.out.println(i+":"+list.get(i));
      }
      //정보를 수정할 친구 인덱스로 처리
      System.out.print("수정할 친구의 번호를 입력하시오.>> ");
      int choice = sc.nextInt();
      
      //친구가 인덱스 안에 있을 경우에만 처리!
      if(choice >= 0 && choice < list.size()) {
         System.out.print("수정할 항목을 입력하세요. (1이름 2나이 3성별 4주소 5자동차)>> ");
         int key = sc.nextInt();
         switch(key) {
         case 1://이름변경
            System.out.print("새로운 이름을 입력하세요.>> ");
            String newName = sc.next();
            list.get(choice).name = newName; 
            break;
         case 2://나이변경
            System.out.print("새로운 나이를 입력하세요.>> ");
            int newAge = sc.nextInt();
            list.get(choice).age = newAge;
            break;
         case 3://성별변경
            System.out.print("새로운 성별을 입력하세요.>> ");
            char newGender = sc.next().charAt(0);
            list.get(choice).gender = newGender;
            break;
         case 4://주소변경
            System.out.print("새로운 주소를 입력하세요.>> ");
            String newAddr = sc.next();
            list.get(choice).address = newAddr;
            break;
         case 5://자동차변경
            System.out.print("자동차 보유 여부를 입력하세요.>> ");
            boolean newCar = sc.nextBoolean();
            list.get(choice).car = newCar;
            break;
         default:
            System.out.println("항목 숫자만 입력해주세요");
            break;
         }
         System.out.print("업데이트되었습니다.");
      } else {
         System.out.print("친구 번호를 다시 확인해주세요");
      }
      
      //sc.close();
   }
   
   //친구 삭제
   public static void delete(ArrayList<해시문제> list) {
      
      Scanner sc = new Scanner(System.in);
      //친구리스트 없을 때 그냥 패스
      if (list.size() == 0){
         System.out.println("친구가 아직 없습니다... 친구 없으면 절교도 못해");
         return;
      }
      //친구리스트 출력
      System.out.println("[친구 리스트]");
      for (int i = 0; i < list.size(); i++) {
         System.out.println(i+":"+list.get(i));
      }
      //삭제할 친구 인덱스로 처리
      System.out.print("삭제할 친구의 번호를 입력하세오.>> ");
      int choice = sc.nextInt();
      //친구가 인덱스 안에 있을 경우에만 처리!
      if(choice >= 0 && choice < list.size()) {
         System.out.println(list.get(choice).name+"님 친구리스트 삭제 완료");
         list.remove(choice);
      } else {
         System.out.print("친구 번호를 다시 확인해주세요");
      }
      //sc.close();
   }
   
   public static void friendsList(ArrayList<해시문제> list) {
		
		System.out.println("친구 목록");
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i + 1) + "번 : " + list.get(i));	
			System.out.println("=============================");		
		}
	
	} 
	

	public static void addlist(ArrayList<해시문제> list) {
		해시문제 friend = new 해시문제();
		Scanner sc = new Scanner(System.in);
		System.out.print("추가하실 친구의 정보를 입력해주세요.");
		System.out.println("=================");
		System.out.print("친구 이름 : ");
		friend.name = sc.next();
		System.out.print("친구 나이 : ");
		friend.age = sc.nextInt();
		System.out.print("친구 성별 : ");
		friend.gender= sc.next().charAt(0);
		System.out.print("친구 주소 : ");
		friend.address = sc.next();
		System.out.print("친구 차소유 여부 : ");
		friend.car = sc.nextBoolean();
		System.out.println("친구목록이 업데이트 되었습니다.");
		list.add(friend);
	}
   
   
   
   
   public static void main(String[] args) {

      //친구목록 들어갈 리스트
      ArrayList<해시문제> list = new ArrayList<해시문제>(); 
      해시문제 friend1 = new 해시문제();
      friend1.name = "홍길동";
      friend1.age = 100;
      friend1.gender = 'M';
      friend1.address = "한국";
      friend1.car = false;
      list.add(friend1);
      
      
      Scanner sc = new Scanner(System.in);
      while (true) {
         //메뉴 출력
         menuOut();
         //메뉴 선택 Input
         int choice = sc.nextInt();
         if (choice == 9) {
            System.out.println("시스템을 종료합니다.");
            break;
         }else if (choice == 1) { //1. 친구 리스트 출력
            friendsList(list);
         }else if (choice == 2) { //2. 친구 추가
            addlist(list);
         }else if (choice == 3) { //3. 친구 삭제
            delete(list);
         }else if (choice == 4) { //4. 정보 변경
            modify(list);
            
         }else { //1~4, 9도 아닌 경우
            JOptionPane.showInputDialog(null, "해당 숫자가 없습니다. 다시입력하세요.");
         }
      }
      sc.close();
   }

}