package 문제;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class 문제3 {

	public static void main(String[] args) {
		HashMap<String, String> friends = new HashMap<>(); 
		friends.put("홍길동", "011-1234-5678");
		friends.put("김길동", "010-2345-6789");
		
		
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("===============");
			System.out.println("1. 친구 리스트 출력");
			System.out.println("2. 친구 추가");
			System.out.println("3. 친구 삭제");
			System.out.println("4. 이름 변경");
			System.out.println("9. 종료");
			System.out.print("메뉴를 선택하시오 : ");
			int menu = sc.nextInt();

			System.out.println("===============");
			if (menu == 9) {
				System.out.println("시스템을 종료합니다.");
				break;
			} else if (menu == 2) {
				System.out.print("추가할 친구이름 입력 : ");
				String name = sc.next();
				System.out.print("추가할 친구전화번호 입력 : ");
				String cell = sc.next();
				int size1 = friends.size();
				friends.put(name, cell);
				int size2 = friends.size();
				if (size1 < size2) {
					System.out.println("친구가 추가되었습니다.");
				}
			} else if (menu == 1) {
				System.out.print("친구리스트 : " + friends);
				System.out.println("");
			
			} else if (menu == 3) {
				System.out.print("친구목록 : " + friends);
				System.out.print("삭제할 친구이름 입력 : ");
				String name = sc.next();
				friends.remove(name);
			} else if (menu == 4) {
				System.out.print(friends.keySet());
				System.out.print("변경하실 친구의 이름을 입력하시오 : ");
				String name = sc.next();
				System.out.print("변경전 전화번호를 입력하시오 : ");
				String cell1 = sc.next();
				System.out.print("변경후 전화번호를 입력하시오 : ");
				String cell2 = sc.next();
				friends.replace(name, cell1, cell2);
			} 
			else {
				System.out.println("해당 숫자가 없습니다. 다시 입력하세요.");
			}
		}
		sc.close();
	}
}
