package 문제;

import java.util.ArrayList;
import java.util.Scanner;

public class 문제1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> arr1 = new ArrayList<>();
		arr1.add("홍길동");
		arr1.add("김길동");
		while (true) {
			System.out.println("===============");
			System.out.println("1. 친구 리스트 출력");
			System.out.println("2. 친구 추가");
			System.out.println("3. 친구 삭제");
			System.out.println("4. 이름 변경");
			System.out.println("5. 단축키 확인");
			System.out.println("9. 종료");
			System.out.print("메뉴를 선택하시오 : ");
			int menu = sc.nextInt();

			System.out.println("===============");
			if (menu == 9) {
				System.out.println("시스템을 종료합니다.");
				break;
			} else if (menu == 2) {
				System.out.print("추가할 친구이름 입력 : ");
				String name = sc.next();
				int size1 = arr1.size();
				arr1.add(name);
				int size2 = arr1.size();
				if (size1 < size2) {
					System.out.println("친구가 추가되었습니다.");
				}
			} else if (menu == 1) {
				System.out.print("친구리스트 : " + arr1);
				System.out.println("");
			} else if (menu == 3) {
				System.out.print("친구목록 : " + arr1);
				System.out.print("삭제할 친구이름 입력 : ");
				String name = sc.next();
				arr1.remove(arr1.indexOf(name));
			} else if (menu == 4) {
				System.out.print(" ");
				System.out.print("변경전 이름을 입력하시오 : ");
				String name = sc.next();
				System.out.print("변경후 이름을 입력하시오 : ");
				String name2 = sc.next();
				int n1 = arr1.indexOf(name);
				arr1.set(n1, name2);
			} else if (menu == 5) {
				System.out.print(" ");
               for (int i = 0; i < arr1.size(); i++) {
				System.out.println(i + "번 :  " + arr1.get(i));
			}	}
			else {
				System.out.println("해당 숫자가 없습니다. 다시 입력하세요.");
			}
		}
		sc.close();
	}
}