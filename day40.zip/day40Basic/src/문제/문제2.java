package 문제;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class 문제2 {

	public static String ssn() {
		String ssnNumber = "";

		int[] dates = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		Random r = new Random();
		int year = r.nextInt(60) + 40; // 숫자 40~99 랜덤
		int month = r.nextInt(12) + 1; // 1~12
		int date = r.nextInt(3100) % dates[month - 1] + 1; // 1~각 월의 마지막 일의 랜덤 숫자가 나오도록
		int num = r.nextInt(2000000) + 1000000;

		String monthS = month > 9 ? Integer.toString(month) : "0" + month;

		String dateS = date > 9 ? Integer.toString(date) : "0" + date;

		ssnNumber += year + monthS + dateS + "-" + num;
		return ssnNumber;

	}

// 주민등록번호 기반 나이
	public static int age(String ssn) {
		int age = -1;
		age = 121 - Integer.parseInt(ssn.substring(0, 2)) + 1; // 2021- 1900 => 121
		// substring 으로 범위 지정 0과 1자리의 String 값을 가져옴
		return age;
	}

	// 주민번호 기반 성별(남성) 계산
	public static boolean genderM(String ssn) {
		boolean gender;
		int num = Integer.parseInt(ssn.substring(7,8));
		if
		
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("주민번호 생성 개수를 입력하세요.>>> ");

		int amount = sc.nextInt();
		sc.close();

		ArrayList<String> ssnList = new ArrayList<>();

		for (int i = 0; i < amount; i++) {
			String s1 = ssn();
			ssnlist.add(s1);
			System.out.println(s1);

		}

		/// 1. 주민등록번호를 생성하는 메서드를 만들고(Random 이용) 입력받은 개수 만큼 주민번호를 출력하는 프로그램을 만들어보자
		// 조건 1) 주민등록번호는 1.6자리 생년월일 2."-" 3. 7자리의 1혹은 2로 시작하는 랜덤 넘버로 구성한다
		// 조건 2) 주민등록번호는 1940년(을 포함한) 이후 및 1999년(을 포함한) 이전의 연도로 한정하며,
		// 월 및 일은 실제 달력에 기반하여 생성해야한다 (2월 30일은 있을 수 없으며, 편의상 윤년은 없는 셈 친다)
		// 조건 3) 주민등록번호 뒷자리는 1 혹은 2로 시작해야하며, 그 이후의 숫자는 어떤 수여도 상관없다

	}

}
