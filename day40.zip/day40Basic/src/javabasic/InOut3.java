package javabasic;

import java.util.Scanner;

public class InOut3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		int[] jumsu = new int[5];
		// int[] jumsu = { 0, 0, 0, 0, 0 };
		for (int i = 0; i < 5; i++) {
			System.out.print("오늘 온도는 몇도인가요?");
			int temp = sc.nextInt();

			if (temp >= 30) {
				System.out.println("아이스크림을 먹자");
			} else {
				System.out.println("그만 더워라");
			}
			jumsu[i] = temp;
			
			sum = sum + temp;
		}
		double avg = sum / 5.0;
		System.out.println("평균은 " + avg);
		System.out.println("================");
		for (int i = 0; i < jumsu.length; i++) {
			System.out.print(jumsu[i] + " ");
		}
		sc.close();

	}
}