package javabasic;

import java.util.Scanner;

public class InOut5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String[] lunch1 = new String[5];
		int sum = 0;

		for (int i = 0; i < 5; i++) {

			System.out.print("오늘 점심메뉴는 무엇인가요?");
			lunch1[i] = sc.next();
			System.out.print("오늘 점심값은 얼마인가요?");
			int price = sc.nextInt();
			if (price >= 10000) {
				System.out.println(lunch1[i] + " 비쌈");
			} else {
				System.out.println(lunch1[i] +" 잘 먹음");
			}
			
			sum = sum + price;
		}
		double avg = sum / 5.0;
		System.out.println("평균은 " + avg);
		System.out.println("==================");
		for (int i = 0; i < lunch1.length; i++) {
			System.out.print(lunch1[i] + " ");
		}

		sc.close();

	}
}