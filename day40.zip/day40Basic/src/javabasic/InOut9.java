package javabasic;

import java.util.ArrayList;
import java.util.Scanner;

public class InOut9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("시작값을 입력해주세요 >>  ");
		int s1 = sc.nextInt(); // 시작변수
		System.out.print("종료값을 입력해주세요 >>  ");
		int s2 = sc.nextInt(); // 종료변수
		int sum = 0;   // 배수더한값 넣을 변수
		int count = 0; // 개수더한값 넣을 변수
		ArrayList arr1 = new ArrayList();
		while (s1 < s2) { // 조건
			if (s1 % 5 == 0) { // 몫이 0
				sum += s1;
				count ++;
			}
			s1++;
		}
		System.out.println(sum);  // 배수 더한 값 출력
		System.out.println(count);
		System.out.println(sum / count);
		sc.close();

	}
}