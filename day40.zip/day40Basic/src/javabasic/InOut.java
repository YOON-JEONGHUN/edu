package javabasic;

import java.util.Scanner;

public class InOut {

	public static void main(String[] args) {
		// scanner 는 기본생성자를 제공하지 않음
		Scanner sc = new Scanner(System.in);
		

			for (int i = 0; i < 5; i++) {
				System.out.print("오늘 온도는 몇도인가요?");
				int temp = sc.nextInt();
				if (temp >= 30) {
					System.out.println("너무 더워요");
				} else if (temp < 30) {
					System.out.println("괜찮아요!");
				} 
			}
		sc.close();
	}
}
