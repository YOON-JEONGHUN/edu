package javabasic;

import java.util.Scanner;

public class InOut4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 변수초기화는 반드시 해주어야 하는 경우?
		// 변수초기화는 반드시 해주어야함
		// 자동으로 되는 경우가 있음(전역변수, 멤버변수 자동 초기화 됨)
		// 자동으로 안되는 경우는 수동으로 초기화 해주어야 함
		// 전역변수는 클래스 전체영역에서 사용가능한 변수
		// 변수 선언의 위치에 따라 사용할 수 있는 범위가 달라짐
		// 변수 선언이 클래스 바로 아래되어야 함(<== 전역변수)
		
		int sum = 0;

		for (int i = 0; i < 5; i++) {
			System.out.print("오늘 온도는 몇도인가요?");
			int temp = sc.nextInt();

			if (temp >= 30) {
				System.out.println("아이스크림을 먹자");
			} else {
				System.out.println("그만 더워라");
			}
			sum = sum + temp;
		}
		double avg = sum / 5.0;
		System.out.println("평균은 " + avg);
		sc.close();

	}
}