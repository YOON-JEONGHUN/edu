package javabasic;

import java.util.Scanner;

public class InOut2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < 5; i++) { // 반복문 5번 실행
			System.out.print("오늘 온도는 몇도인가요?"); // 조건1
			int temp = sc.nextInt(); 
			System.out.print("어제보다 덥나요? (true, false)"); // 조건2
			Boolean b1 = sc.nextBoolean();
			if (temp >= 30 && b1 == true ) { // 조건비교 
				System.out.println("아이스크림을 먹자");
			} else if (temp >= 30 && b1 == false ) {
				System.out.println("그만 더워라");
			} else if (temp < 30 && b1 == true) {
				System.out.println("가만히 있자");
			} else {
				System.out.println("이제 여름이 끝나감");
			}
		}
		sc.close();

	}
}