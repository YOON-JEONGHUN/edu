package javabasic;

import java.util.ArrayList;
import java.util.Scanner;

public class InOut7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("시작값을 입력해주세요 >>  ");
		int s1 = sc.nextInt();
		System.out.print("종료값을 입력해주세요 >>  ");
		int s2 = sc.nextInt();
		int sum = 0;
		int count = 0; // 개수더한값 넣을 변수
		ArrayList arr1 = new ArrayList(); 
		for (int i = s1; i <= s2; i++) {
			if (i % 5 == 0) {
				sum += i;
			count ++ ;
			arr1.add(i);
 		}
		}
		System.out.println(sum);
		System.out.println(count);
		System.out.println(sum / count);
		System.out.println(arr1);
		sc.close();
	}
}