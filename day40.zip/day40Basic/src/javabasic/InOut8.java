package javabasic;

public class InOut8 {

	public static void main(String[] args) {
	
		int sum = 0;
		int count = 100;
		while (count < 500) {
			sum += count;
			count ++;
		}
	System.out.println(sum);					
		
	}
}