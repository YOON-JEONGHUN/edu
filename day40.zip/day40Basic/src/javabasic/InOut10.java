package javabasic;

import java.util.ArrayList;
import java.util.Random;


public class InOut10 {

	public static void main(String[] args) {

		Random r1 = new Random(100); // seed값, 씨앗값
		//  int start = r1.nextInt(999);  0~998까지 
		int start = r1.nextInt(100);
		int end = r1.nextInt(10) + 1000;
		int sum = 0;
		ArrayList arr1 = new ArrayList(); 
		for (int i = start ; i < end; i++) {
			if(i % 3 == 0) {
				sum += i;
				arr1.add(i);
			}
				}
		System.out.println("3의 배수의 합은 " + sum);
		System.out.println("3의 배수의 목록은 " + arr1);
		System.out.println("3의 배수의 개수는 " + arr1.size());
		System.out.println(arr1.get(0));
		System.out.println(arr1.get(arr1.size()));
		
	}
}