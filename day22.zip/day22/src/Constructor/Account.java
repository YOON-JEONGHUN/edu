package Constructor;

public class Account {
	String name;
	String ssn;
	int money;

	//public Account() {
			// 입력값없는 생성자는 기본생성자라 한다.  default constructor
			// 다른 생성자가 하나도 없으면 자동 생성
	//}

	public Account(String name, String ssn, int money) {
		this.name = name;
		this.ssn = ssn;
		this.money = money;
	}	

	public void input() {
		System.out.println("입금하다");
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", ssn=" + ssn + ", money=" + money + "]";
	}
	


}
