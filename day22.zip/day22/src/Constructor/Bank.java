package Constructor;

public class Bank {

	public static void main(String[] args) {
		Account acc1 = new Account("홍길동", "990101", 10000);
		Account acc2 = new Account("김길동", "980102", 20000);

		System.out.println(acc1);
		System.out.println(acc2);

	}

}
