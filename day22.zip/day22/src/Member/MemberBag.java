package Member;

public class MemberBag {

	String id;
	String password;
	String name;
	String tel;

	public MemberBag(String id, String password, String name, String tel) {
		this.id = id;
		this.password = password;
		this.name = name;
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "MemberBag [id=" + id + ", password=" + password + ", name=" + name + ", tel=" + tel + "]";
	}
	
	

}
