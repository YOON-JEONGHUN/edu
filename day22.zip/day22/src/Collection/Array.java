package Collection;

import java.util.ArrayList;

public class Array {

	public static void main(String[] args) {

		ArrayList list = new ArrayList();

		list.add("홍길동");
		list.add(100);
		list.add(22.22);
		list.add(true);
		list.add("목요일");
		list.add('남');
		System.out.println(list.size());
		System.out.println(list);
		System.out.println(list.get(0));

		list.remove(5);
		list.remove("홍길동");
list.add(0, "김길동");
System.out.println(list);

	}
}
