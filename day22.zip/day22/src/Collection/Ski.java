package Collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

public class Ski {

	public static void main(String[] args) {
				
		ArrayList ski = new ArrayList();
		ski.add(0, "박스키");
		ski.add(1, "송스키");
		ski.add(2, "김스키");
		ski.add(3, "정스키");

		ski.remove(1);
		System.out.println(ski);
		for (int i = 0; i < ski.size(); i++) {
			System.out.println(i + 1 + "등 : " + ski.get(i));
		}
		for (Object o : ski) {
			System.out.println(o);
		}
		
		HashMap phone = new HashMap();
		phone.put("1", "엄마");
		phone.put("2", "아빠");
		phone.put("3", "친구");
		phone.put("4", "동생");
		System.out.println(phone.get("2"));
		
		
		HashSet team = new HashSet ();
		team.add("디자이너");
		team.add("프로그래머");
		team.add("DB관리자");
		team.add("프로그래머");
		System.out.println(team);
		
		LinkedList milk = new LinkedList();
		milk.add("상한우유");
		milk.add("싱싱우유");
		milk.remove();
		System.out.println(milk);
		
		ArrayList sub = new ArrayList();
		sub.add("국어");
		sub.add("수학");
		sub.add("영어");
		sub.add("컴퓨터");
		System.out.println(sub);
//		sub.remove(0);
//		System.out.println("1일차 시험본 후 남은과목 : " + sub);
//		sub.remove(0);
//		System.out.println("2일차 시험본 후 남은과목 : " + sub);
//		sub.remove(0);
//		System.out.println("3일차 시험본 후 남은과목 : " + sub);
		
		for (int i = 0; i < 3; i++) {
			sub.remove(0);
			System.out.println(i + 1 +"일차 시험본 후 남은 과목 : " + sub);
		}
		
		
		
	}

}
