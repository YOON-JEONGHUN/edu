package 생성자;

public class phone {

	String tel;
	String num;
	String index;
	
	public phone(String tel, String num, String index) {
		this.tel = tel;
		this.num = num;
		this.index = index;
	}

	public String toString() {
		return "phone [tel=" + tel + ", num=" + num + ", index=" + index + "]";
	}

	
	
	
}
