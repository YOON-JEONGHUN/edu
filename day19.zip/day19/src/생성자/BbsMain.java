package 생성자;

public class BbsMain {

	public static void main(String[] args) {
		Bbs b1 = new Bbs("1", "java", "fun java", "park" );
		Bbs b2 = new Bbs("2", "jsp", "fun jsp", "hong" );
		Bbs b3 = new Bbs("3", "spring", "fun spring", "kim" );
		
		
		System.out.println("no.1 : " + b1);
		System.out.println("no.2 : " + b2);
		System.out.println("no.3 : " + b3);

	}

}
