package 생성자;

public class Computer {

	public static void main(String[] args) {
		Com c1 = new Com(10000, "APPLE", 30);
		Com c2 = new Com(20000, "BANANA", 20);
		
		System.out.println(c1);
		System.out.println(c2);

	}

}
