package 생성자;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class typeA {

	public static void main(String[] args) {
		typeA a = new typeA();
		a.open();
		
	}
	
	public typeA() {
		System.out.println("A객체가 생성됨");
	}
	
	
	
	public void open() {
		JFrame f = new JFrame("A");
		f.setSize(300, 300);
		JButton b = new JButton("B open");
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				typeB x = new typeB();
				x.open();
				f.dispose();
			}
		});
		f.add(b);
		
		
		
		
		f.setVisible(true);
	}

}
