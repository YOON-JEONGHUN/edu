package 생성자;

public class tvfac {

	public static void main(String[] args) {
		tv t1 = new tv("white", 2500);
		tv t2 = new tv("black", 3000);

		System.out.println("tv1: " + t1);
		System.out.println("tv2: " + t2);
	}

}
