package 생성자;

public class maskfac {

	public static void main(String[] args) {
	mask m1 = new mask("white", 2500);
	mask m2 = new mask("black", 3000);
//	System.out.println(m1);
//	System.out.println(m2);
//	m1.price = 2500;
//	m1.color = "white";
//	
//	m2.price = 3000;
//	m2.color = "black";
	
	System.out.println(m1);
	System.out.println(m2);
	}

}
