package 생성자;

public class phonefac {

	public static void main(String[] args) {
		phone p1 = new phone("sk", "011", "엄마");
		phone p2 = new phone("lg", "010", "아빠");
		
		
		System.out.println("엄마폰: " + p1);
		System.out.println("아빠폰: " + p2);
	}

}
