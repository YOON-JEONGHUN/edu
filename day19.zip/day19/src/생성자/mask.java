package 생성자;

public class mask {
	//속성 = 변수
	// 멤버변수는 자동초기화
	
	String color; // 참조형변수는 null
	int price; // 기본형 변수는 0
	
	// 생성자 메서드 = 생성자
	
	public mask(String c, int p) {
		color = c;
		price = p;
	}
	//동작 = 메서드
	public void cover() {
	 System.out.println("마스크를 쓰다. ");
	}
	
	
	public String toString() {
		return color + " " + price;
	}
}
