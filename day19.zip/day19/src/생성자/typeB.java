package 생성자;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class typeB {

	public typeB() {
		System.out.println("B객체가 생성됨");
	}
	
	public void open() {
		JFrame f = new JFrame("B");
		f.setSize(300, 300);
		JButton b = new JButton("A open");
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				typeA y = new typeA();
				y.open();
				f.dispose();
			}
		});
		f.add(b);
		
		
		
		
		
		f.setVisible(true);
	}

}
