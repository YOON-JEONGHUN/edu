package 생성자;

public class Com {

	int price;
	String company;
	int inch;
	public Com(int price, String company, int inch) {
		
		this.price = price;
		this.company = company;
		this.inch = inch;
	}
	
	public String toString() {
		return "Computer [price=" + price + ", company=" + company + ", inch=" + inch + "]";
	}
	
	
}
