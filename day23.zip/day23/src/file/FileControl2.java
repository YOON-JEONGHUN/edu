package file;

import java.io.File;

public class FileControl2 {

	public static void main(String[] args) {
		File file = new File("C:\\Program Files\\Java\\jre1.8.0_291");
		File[] list = file.listFiles();
		for (File file2 : list) {
			System.out.println(file2);
			if (file2.isDirectory() == true) {
				System.out.println("폴더");
			} else {
				System.out.println("파일");
			}
		}
		
	} // main

} // class
