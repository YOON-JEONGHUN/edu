package shop.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import shop.dto.Member_DTO;

public class Member_DAO {

	public int create(Member_DTO bag) {
		int result = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. member db연결 성공!!!");

			String sql = "insert into member values (?, ?, ?, ?)";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getId());
			ps.setString(2, bag.getPw());
			ps.setString(3, bag.getName());
			ps.setString(4, bag.getTel());
			System.out.println("3. sql문 생성 성공!!!");

			result = ps.executeUpdate();
			System.out.println("4. sql문 전송 전송");
			System.out.println(result);
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
		}

		return result;

	}

	public int delete(Member_DTO bag) {
		int result = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. shoes db연결 성공!!!");

			String sql = "delete from member where id= ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getId());

			System.out.println("3. sql문 생성 성공!!!");

			result = ps.executeUpdate();
			System.out.println("4. sql문 전송 전송");
			System.out.println(result);
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
		}
		return result;
	}

	public int update(Member_DTO bag) {
		int result = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. shoes db연결 성공!!!");

			String sql = "update member set tel=?, name=? where id= ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getTel());
			ps.setString(2, bag.getName());
			ps.setString(3, bag.getId());

			System.out.println("3. sql문 생성 성공!!!");

			result = ps.executeUpdate(); // CUD 일때만 executeupdate
			System.out.println("4. sql문 전송 전송");
			System.out.println(result);
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
		}
		return result;
	}

	public Member_DTO read(Member_DTO bag) {
		ResultSet rs = null;
		Member_DTO bag2 = new Member_DTO();
		try {
			System.out.println("전달된 id는 " + bag.getId());
			System.out.println("전달된 pw는 " + bag.getPw());
			System.out.println("전달된 name는 " + bag.getName());
			System.out.println("전달된 tel는 " + bag.getTel());
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. member db연결 성공!!!");

			String sql = "select * from member where id= ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getId());

			System.out.println("3. sql문 생성 성공!!!");

			rs = ps.executeQuery();
			System.out.println("4. sql문 전송 전송");
//			System.out.println("검색결과는 >> " + rs.next());
			if (rs.next()) {
				System.out.println("검색결과가 있음.");
				String id = rs.getString(1); // table 안의 1번 column, rs.getString("id")
				String pw = rs.getString(2); // table 안의 2번 column
				String name = rs.getString(3); // table 안의 3번 column
				String tel = rs.getString(4); // table 안의 4번 column
				System.out.println(id + "" + pw + "" + name + "" + tel);
				bag2.setId(id);
				bag2.setPw(pw);
				bag2.setName(name);
				bag2.setTel(tel);
			} else {
				System.out.println("검색결과가 없음.");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");
			e.printStackTrace();

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}

		return bag2;

	}

	public ArrayList<Member_DTO> read() {
		ResultSet rs = null;

		ArrayList<Member_DTO> list = new ArrayList<Member_DTO>();

		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. member db연결 성공!!!");

			String sql = "select * from member";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.println("3. sql문 생성 성공!!!");

			rs = ps.executeQuery();
			System.out.println("4. sql문 전송 전송");
//			System.out.println("검색결과는 >> " + rs.next());
			while (rs.next()) {
				System.out.println("검색결과가 있음.");
				Member_DTO bag2 = new Member_DTO();
				String id = rs.getString(1); // table 안의 1번 column, rs.getString("id")
				String pw = rs.getString(2); // table 안의 2번 column
				String name = rs.getString(3); // table 안의 3번 column
				String tel = rs.getString(4); // table 안의 4번 column
				System.out.println(id + "" + pw + "" + name + "" + tel);
				bag2.setId(id);
				bag2.setPw(pw);
				bag2.setName(name);
				bag2.setTel(tel);
				list.add(bag2);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");
			e.printStackTrace();

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}

		return list;

	}

}
