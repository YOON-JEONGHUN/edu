
package shop.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import shop.dto.ProductDTO;

public class ProductDAO {

	public ProductDTO read(ProductDTO bag) {
		ResultSet rs = null;
		ProductDTO bag2 = new ProductDTO();
		try {
			System.out.println("전달된 id는 " + bag.getId());

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. product db연결 성공!!!");

			String sql = "select * from product where id = ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, bag.getId());

			System.out.println("3. sql문 생성 성공!!!");

			rs = ps.executeQuery();
			System.out.println("4. sql문 전송 전송");
			
			if (rs.next()) {
				System.out.println("검색결과가 있음.");
				String id = rs.getString(1);
				String name = rs.getString(2);
				String content = rs.getString(3);
				String price = rs.getString(4);
				System.out.println(id + "" + name + "" + content + "" + price);
				bag2.setId(id);
				bag2.setName(name);
				bag2.setContent(content);
				bag2.setPrice(price);
			} else {
				System.out.println("검색결과가 없음.");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");
			e.printStackTrace();

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}

		return bag2;

	}

	public ArrayList<ProductDTO> read() {
		ResultSet rs = null;
		ArrayList<ProductDTO> list = new ArrayList<>();

		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("2. product db연결 성공!!!");

			String sql = "select * from product";

			PreparedStatement ps = con.prepareStatement(sql);

			System.out.println("3. sql문 생성 성공!!!");

			rs = ps.executeQuery();
			System.out.println("4. sql문 전송 전송");

			while (rs.next()) {
				ProductDTO bag2 = new ProductDTO();
				bag2.setId(rs.getString(1));
				bag2.setName(rs.getString(2));
				bag2.setContent(rs.getString(3));
				bag2.setPrice(rs.getString(4));

				list.add(bag2);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("1번에러 >> 드라이버 없음!!");
			e.printStackTrace();

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}

		return list;

	}

}
