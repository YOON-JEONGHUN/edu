package inheritance;

public class BossBaby extends Baby {

	boolean rich;

	@Override
	public String toString() {
		return "BossBaby [rich=" + rich + ", young=" + young + ", name=" + name + ", age=" + age + "]";
	}
	
}
