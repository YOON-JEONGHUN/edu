package inheritance;

public class PersonUse {

	public static void main(String[] args) {
		Person p1 = new Person("hong", 100);
		Person p2 = new Person("kim", 200);

		System.out.println(p1);
		System.out.println(p2);
	}

}
