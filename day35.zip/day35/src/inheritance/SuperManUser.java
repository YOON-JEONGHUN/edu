package inheritance;

public class SuperManUser {

	public static void main(String[] args) {
		SuperMan sMan = new SuperMan();
		sMan.name = "park"; // Person에서 상속
		sMan.age = 1000; // Person에서 상속
		sMan.power = 3000; // Man에서 상속
		sMan.fly = true;

		System.out.println(sMan);
		sMan.think();
		sMan.tool();
		sMan.run();
		sMan.space();

	}
}
