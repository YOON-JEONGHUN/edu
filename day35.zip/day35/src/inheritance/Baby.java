package inheritance;

public class Baby extends Person{

	boolean young;
	
	public void 기어다님() {
		System.out.println("기어다님");
	}

	@Override
	public String toString() {
		return "Baby [young=" + young + ", name=" + name + ", age=" + age + "]";
	}

	}

