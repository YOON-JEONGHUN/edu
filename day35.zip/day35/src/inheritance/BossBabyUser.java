package inheritance;

public class BossBabyUser {

	public static void main(String[] args) {
		BossBaby bBaby = new BossBaby();
bBaby.young = true;
bBaby.age = 5;
bBaby.기어다님();
bBaby.rich = false;
	}

}
