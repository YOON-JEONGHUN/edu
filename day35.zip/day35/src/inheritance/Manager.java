package inheritance;

public class Manager extends Employee {
int bonus;
public void test() {
	System.out.println("모름");
}
@Override
public String toString() {
	return "Manager [bonus=" + bonus + ", name=" + name + ", address=" + address + ", salary=" + salary + ", rrn=" + rrn
			+ "]";
}
	
}
