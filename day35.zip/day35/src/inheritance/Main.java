package inheritance;

public class Main {

	public static void main(String[] args) {
Manager m1 = new Manager();
m1.address ="주소";
m1.name ="hong";
m1.test();

System.out.println(m1);
	}

}
