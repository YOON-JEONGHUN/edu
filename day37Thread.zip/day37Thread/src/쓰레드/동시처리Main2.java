package 쓰레드;

public class 동시처리Main2 {

	public static void main(String[] args) {
		
		// 만든 thread 객체 생성
		AtThread thr1 = new AtThread();
		DollarThread thr2 = new DollarThread();
		PercentThread thr3 = new PercentThread();
		
		// cpu에 thread를 등록해줘야 함.
		thr1.start();
		thr2.start();
		thr3.start();

		System.out.println("스레드 종료"); // 메인부터 처리하므로 주의
	}

}
