package 쓰레드;

import java.util.Date;

public class Timer1 extends Thread {

	@Override // 지워도 됨. override 했다는 의미
	public void run() {

		for (int i = 0; i < 1000; i++) {
			Date date = new Date();
			System.out.println(date);
			try {
				Thread.sleep(1000); // 밀리세컨즈(1/1000초)
			} catch (InterruptedException e) {

				e.printStackTrace();
			}

		}
	}
}
