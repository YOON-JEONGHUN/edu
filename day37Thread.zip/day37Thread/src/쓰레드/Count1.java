package 쓰레드;

public class Count1 extends Thread {

	@Override // 지워도 됨. override 했다는 의미
	public void run() {
		// i-- (증감연사자) => i = i - 1;
		for (int i = 1000; i >= 0; i = i - 2) {
			System.out.println(i + " 분 남았습니다.");

			try {
				Thread.sleep(500);   // 밀리세컨즈(1/1000초)
			} catch (InterruptedException e) {

				e.printStackTrace();
			} 
		}
	}
}
