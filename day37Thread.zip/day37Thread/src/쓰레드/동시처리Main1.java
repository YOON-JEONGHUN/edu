package 쓰레드;

public class 동시처리Main1 {

	public static void main(String[] args) {
		
		// 만든 thread 객체 생성
		동시1 thread1 = new 동시1();
		동시2 thread2 = new 동시2();
		
		// cpu에 thread를 등록해줘야 함.
		thread1.start();
		thread2.start();

		System.out.println("스레드 종료"); // 메인부터 처리하므로 주의
	}

}
