package 쓰레드;

public class 동시처리Main3 {

	public static void main(String[] args) {
		
		// 만든 thread 객체 생성
		Count1 thr1 = new Count1();
		Image1 thr2 = new Image1();
		Timer1 thr3 = new Timer1();
		
		// cpu에 thread를 등록해줘야 함.
		thr1.start();
		thr2.start();
		thr3.start();
	
	}

}
