package 쓰레드;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ThreadGraphic1 extends JFrame {

	// static이라 붙으면 객체생성하지 않아도 cpu가 바로 호출해서 사용할 수 있음.
	// 멤버변수가 있으면 static메서드에서 바로 사용 불가능
	// 전역변수에도 static을 붙여주면 객체생성하지 않아도 static메서드안에서 접근 가능
	// static이라고 하는것은 RAM에 항상 상주. 언제든지 cpu가 접근해서 사용 가능
	// static을 많이 사용하면 메모리를 많이 사용하는 것이므로 지양.

	JLabel count, image, timer;

//	public void start() {
//	}

	public ThreadGraphic1() {
		setSize(800, 350);
		setTitle("나의 스레드 프로그램");

// 원래 아래처럼 정의를 해야하지만, 변수를 공유하기 위해 class 위로 빼줌	
//	JLabel count = new JLabel("카운트 들어감");
//	JLabel image = new JLabel("이미지 전환");
//	JLabel timer = new JLabel("시간");

		count = new JLabel();
		image = new JLabel();
		timer = new JLabel();

		add(count, BorderLayout.WEST);
		add(image);
		add(timer, BorderLayout.SOUTH);
		Font font = new Font("궁서", Font.BOLD, 40);
		Font font2 = new Font("궁서", Font.BOLD, 30);
		count.setFont(font);
		timer.setFont(font2);

		Count2 thr1 = new Count2();
		Image2 thr2 = new Image2();
		Timer1 thr3 = new Timer1();

		thr1.start();
		thr2.start();
		thr3.start();

		setVisible(true);
	}

	// 클래스간 변수를 공유할 목적으로 클래스내에 클래스를 끼워넣을 수 있음.
	// 내부 클래스(inner class, 이너클래스)
	// 내부로 끼워진 클래스는 독립적으로 다른 곳에서 사용될 수 없다.

	public class Count2 extends Thread {

		@Override // 지워도 됨. override 했다는 의미
		public void run() {
			// i-- (증감연사자) => i = i - 1;
			for (int i = 1000; i >= 0; i = i - 2) {
				count.setText("count>>" + i);
				try {
					Thread.sleep(500); // 밀리세컨즈(1/1000초)
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
			}
		}
	}

	public class Image2 extends Thread {

		@Override // 지워도 됨. override 했다는 의미
		public void run() {
			String[] list = { "1.png", "2.png", "3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png",
					"11.png", "12.png", "13.png", "14.png", "15.png" };
			for (int i = 0; i < list.length; i++) {
				ImageIcon icon = new ImageIcon(list[i]);
				image.setIcon(icon);
				// image.setText(list[i]);

				try {
					Thread.sleep(5000); // 밀리세컨즈(1/1000초)
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}
	}

	public class Timer1 extends Thread {

		@Override // 지워도 됨. override 했다는 의미
		public void run() {

			for (int i = 0; i < 1000; i++) {
				Date date = new Date();
				timer.setText(date + "");

				try {
					Thread.sleep(1000); // 밀리세컨즈(1/1000초)
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}
	}

	public static void main(String[] args) {
		ThreadGraphic1 s = new ThreadGraphic1();

	}

}
