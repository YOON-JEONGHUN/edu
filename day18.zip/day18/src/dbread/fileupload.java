package dbread;

import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class fileupload {

	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(200, 200);
		
		JButton b = new JButton("파일 읽기");
	f.add(b);
	FileDialog file = new FileDialog(f);
	file.setDirectory(".");
	b.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
	file.setVisible(true);
	
	String name = file.getFile();
	System.out.println(name);
			
		}
	});

	f.setVisible(true);
	}

}
