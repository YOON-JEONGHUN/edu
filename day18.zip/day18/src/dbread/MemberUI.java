package dbread;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.xml.transform.Result;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MemberUI {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.CYAN);
		f.setSize(600, 600);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("아이디", Font.PLAIN, 25));
		lblNewLabel.setBackground(new Color(240, 240, 240));
		lblNewLabel.setBounds(54, 55, 94, 65);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uD328\uC2A4\uC6CC\uB4DC");
		lblNewLabel_1.setFont(new Font("패스워드", Font.PLAIN, 25));
		lblNewLabel_1.setBackground(SystemColor.menu);
		lblNewLabel_1.setBounds(54, 130, 157, 65);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\uC774\uB984");
		lblNewLabel_2.setFont(new Font("이름", Font.PLAIN, 25));
		lblNewLabel_2.setBackground(SystemColor.menu);
		lblNewLabel_2.setBounds(54, 324, 94, 65);
		f.getContentPane().add(lblNewLabel_2);

		t1 = new JTextField();
		t1.setFont(new Font("아이디", Font.PLAIN, 20));
		t1.setBounds(223, 61, 230, 55);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setFont(new Font("패스워드", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(223, 136, 230, 55);
		f.getContentPane().add(t2);

		t3 = new JTextField();
		t3.setFont(new Font("이름", Font.PLAIN, 20));
		t3.setColumns(10);
		t3.setBounds(227, 330, 230, 55);
		f.getContentPane().add(t3);

		JButton b1 = new JButton("로그인처리");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		b1.setFont(new Font("삭제", Font.PLAIN, 25));
		b1.setBounds(203, 205, 244, 99);
		f.getContentPane().add(b1);

		JButton b2 = new JButton("결정");
		b2.setFont(new Font("수정", Font.PLAIN, 25));
		b2.setBounds(203, 406, 244, 99);
		f.getContentPane().add(b2);

		f.setVisible(true);

	}
}
