package dbread;

import javax.swing.JOptionPane;

public class readex {

	public static void main(String[] args) throws Exception {
		String id = JOptionPane.showInputDialog("검색할 아이디 입력");

		MemberDB db = new MemberDB();
		String[] result = db.read(id);
System.out.println("검색된 id는 " + result[0]);
System.out.println("검색된 pw는 " + result[1]);
System.out.println("검색된 name는 " + result[2]);
System.out.println("검색된 tel는 " + result[3]);
;	}

}
