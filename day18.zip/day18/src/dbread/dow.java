package dbread;

import javax.swing.JFrame;

public class dow {
JFrame	f = new JFrame();

}
