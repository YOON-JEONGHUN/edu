package crolling;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MainCrolling {

	public static void main(String[] args) {
		try {
			Document doc = Jsoup.connect("http://www.naver.com").get();
			System.out.println("1. 사이트 연결성공.@@@@@");
			System.out.println("2. 소스 받아오기 성공.@@@@@");
			System.out.println(doc);
			Elements list = doc.select("a.nav");
			System.out.println(list.size());
			for (Element tag : list) {
				System.out.println(tag.text());
			}
			Element  aTag = list.get(0);
			Elements list2 = aTag.select("i");
			System.out.println(list2.get(0));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	

}
