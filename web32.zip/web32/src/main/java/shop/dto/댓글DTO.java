package shop.dto;

public class 댓글DTO {
private int id;
private String content;
private String boardid;
private String writer;


public 댓글DTO() {
	super();
	// TODO Auto-generated constructor stub
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getBoardid() {
	return boardid;
}
public void setBoardid(String boardid) {
	this.boardid = boardid;
}
public String getWriter() {
	return writer;
}
public void setWriter(String writer) {
	this.writer = writer;
}

@Override
public String toString() {
	return "댓글DTO [id=" + id + ", content=" + content + ", boardid=" + boardid + ", writer=" + writer + "]";
}

	



}
