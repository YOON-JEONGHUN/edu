
package shop.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import shop.dto.댓글DTO;

public class 댓글DAO {
	Connection con;

	public 댓글DAO() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. connector연결 성공!!!");

			String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf8";
			String username = "root";
			String password = "1234";
			con = DriverManager.getConnection(url, username, password);
			System.out.println("2. shop db연결 성공!!!");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public int create(댓글DTO bag) {
		System.out.println("전달된 id는 " + bag.getId());
		System.out.println("전달된 boardid는 " + bag.getBoardid());
		System.out.println("전달된 content는 " + bag.getContent());
		System.out.println("전달된 writer는 " + bag.getWriter());
		int result = 0;
		try {

			String sql = "insert into reply values (null, ?, ?, ?)";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(2, bag.getBoardid());
			ps.setString(1, bag.getContent());
			ps.setString(3, bag.getWriter());
			System.out.println("3. sql문 생성 성공!!!");

			result = ps.executeUpdate();
			System.out.println("4. sql문 전송 전송");
			System.out.println(result);

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}
		return result;

	}

	public ArrayList<댓글DTO> read(String boardId) {
		ResultSet rs = null;
		ArrayList<댓글DTO> list = new ArrayList<>();

		try {

			String sql = "select * from reply where boardId = ?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, boardId);
			System.out.println("3. sql문 생성 성공!!!");

			rs = ps.executeQuery();
			System.out.println("4. sql문 전송 전송");

			while (rs.next()) {
				댓글DTO bag2 = new 댓글DTO();
				bag2.setId(rs.getInt(1));
				bag2.setBoardid(rs.getString(3));
				bag2.setContent(rs.getString(2));
				bag2.setWriter(rs.getString(4));

				list.add(bag2);
			}

		} catch (SQLException e) {
			System.out.println("2-4번 에러 >> DB관련된 처리하다 에러발생!!");
			e.printStackTrace();
		}

		return list;

	}

}
