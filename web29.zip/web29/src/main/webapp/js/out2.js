/**
 *
  */

function div() {
	alert('나는 추가된 나누기 기능 함수입니다.')


}
