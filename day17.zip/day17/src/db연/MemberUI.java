package db연;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.xml.transform.Result;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MemberUI {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;
	private static JTextField t4;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.CYAN);
		f.setSize(600, 600);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("아이디", Font.PLAIN, 25));
		lblNewLabel.setBackground(new Color(240, 240, 240));
		lblNewLabel.setBounds(54, 55, 94, 65);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uD328\uC2A4\uC6CC\uB4DC");
		lblNewLabel_1.setFont(new Font("패스워드", Font.PLAIN, 25));
		lblNewLabel_1.setBackground(SystemColor.menu);
		lblNewLabel_1.setBounds(54, 130, 157, 65);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\uC774\uB984");
		lblNewLabel_2.setFont(new Font("이름", Font.PLAIN, 25));
		lblNewLabel_2.setBackground(SystemColor.menu);
		lblNewLabel_2.setBounds(54, 218, 94, 65);
		f.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_3.setFont(new Font("전화번호", Font.PLAIN, 25));
		lblNewLabel_3.setBackground(SystemColor.menu);
		lblNewLabel_3.setBounds(54, 301, 169, 65);
		f.getContentPane().add(lblNewLabel_3);

		t1 = new JTextField();
		t1.setFont(new Font("아이디", Font.PLAIN, 20));
		t1.setBounds(253, 55, 230, 55);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setFont(new Font("패스워드", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(253, 130, 230, 55);
		f.getContentPane().add(t2);

		t3 = new JTextField();
		t3.setFont(new Font("이름", Font.PLAIN, 20));
		t3.setColumns(10);
		t3.setBounds(253, 218, 230, 55);
		f.getContentPane().add(t3);

		t4 = new JTextField();
		t4.setFont(new Font("전화번호", Font.PLAIN, 20));
		t4.setColumns(10);
		t4.setBounds(253, 293, 230, 55);
		f.getContentPane().add(t4);

		JButton btnNewButton = new JButton("\uAC00\uC785");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				String name = t3.getText();
				String tel = t4.getText();
				MemberDB db = new MemberDB();
				try {
					int result = db.create(id, pw, name, tel);
					if (result == 1) {
						JOptionPane.showMessageDialog(f, "회원가입성공");
					} else {
						JOptionPane.showConfirmDialog(f, "회원가입실패");
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
			}
		});
		btnNewButton.setFont(new Font("삭제", Font.PLAIN, 25));
		btnNewButton.setBounds(54, 425, 118, 99);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uD0C8\uD1F4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = JOptionPane.showInputDialog("아이디를 입력하세요.");
				MemberDB db = new MemberDB();
				try {
					int result = db.delete(id);
					if (result == 1) {
						JOptionPane.showMessageDialog(f, "아이디가 삭제되었습니다.");
					} else {
						JOptionPane.showMessageDialog(f, "일치하는 아이디가 없습니다.");
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setFont(new Font("수정", Font.PLAIN, 25));
		btnNewButton_1.setBounds(229, 425, 118, 99);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\uC218\uC815");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = JOptionPane.showInputDialog("ID를 입력해주세요");
				String tel = JOptionPane.showInputDialog("수정할 전화번호를 입력하세요");
				MemberDB db = new MemberDB();
				try {
					int result = db.update(id, tel);
					if (result == 1) {
						JOptionPane.showMessageDialog(f, "수정되었습니다");
					} else {
						JOptionPane.showMessageDialog(f, "일치하는 id가 없습니다");
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnNewButton_2.setFont(new Font("삭제", Font.PLAIN, 25));
		btnNewButton_2.setBounds(396, 425, 118, 99);
		f.getContentPane().add(btnNewButton_2);

		f.setVisible(true);

	}
}
