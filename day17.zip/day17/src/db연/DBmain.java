package db연;

public class DBmain {

	public static void main(String[] args) throws Exception {
		MemberDB db = new MemberDB();
		//db.delete();

	}

}
